import json
import pandas as pd
import boto3
import time
from utils import load_to_data_lake,extract_data

print('Loading function')

def lambda_handler(event, context):

    print("value3 = " + event['key3'])
    city=['Bogota','Washington','Johannesburgo','Manila','Boston','Sydney','Paris']
    
    for i in range(len(city)):
        try:
            df=extract_data(city[i])
            load_to_data_lake(df,city[i])
        except:
            print(f"Error extacting data from {city[i]}")

    #Success message
    event['key3']='SUCCESS'
    return event['key3