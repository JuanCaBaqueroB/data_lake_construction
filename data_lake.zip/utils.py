import awswrangler as wr
import pandas as pd

"""
This function read data from a url
@return a dataframe with the url data
"""
def extract_data(name):
    #Dict with cities and urls
    Cities = {'Bogota': 'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Bogota.csv?token=GHSAT0AAAAAAB2X6UWCMI3UY4ZNIPZOCY4SY3HCFSA', 
    'Washington': 'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Washington%20DC.csv?token=GHSAT0AAAAAAB2X6UWDUCJFGCCMENGJMJBAY3G7YIA',
    'Johannesburgo': 'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Johannesburg%20and%20Pretoria.csv?token=GHSAT0AAAAAAB2X6UWDXWN3JZDXJFHIB36MY3G7WTA',
    'Manila':'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Manila.csv?token=GHSAT0AAAAAAB2X6UWC6HVZ7XZ3VB3GFIVMY3G7XKQ',
    'Boston':'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Boston.csv?token=GHSAT0AAAAAAB2X6UWCODT7KVI3EX26GM4EY3G7WDA',
    'Sydney':'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Sydney.csv?token=GHSAT0AAAAAAB2X6UWCHYOVQBVQ2DBGHPSUY3G7X5Q',
    'Paris':'https://raw.githubusercontent.com/JuanCaBaqueroB/data_lake_construction/main/Travel_Times%20-%20Paris.csv?token=GHSAT0AAAAAAB2X6UWCUGGOPO2OAQJXWXW2Y3G7Y2A'
    }
    
    for i in Cities.keys():
        #print(i)
        if i==name:
            url=Cities[name]
            df = pd.read_csv(url)
            break
    
    return df

"""
This function saves a dataframe in a S3 bucket
"""
def load_to_data_lake(df,name):
    print(f"-------------------->Saving file in S3")
    wr.s3.to_csv(df, f's3://data-lake-jcbb/raw-data/{name}.csv', index=False)